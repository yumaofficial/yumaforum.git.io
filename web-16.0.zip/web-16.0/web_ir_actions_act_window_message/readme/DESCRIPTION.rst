This module allows to show a message popup on the client side as result of a button.
