* Holger Brunn <hbrunn@therp.nl>
* Zakaria Makrelouf (ACSONE SA/NV) <z.makrelouf@gmail.com>
* Benjamin Willig (ACSONE SA/NV) <benjamin.willig@acsone.eu>
* Ioan Galan (Studio73) <ioan@studio73.es>
* Abraham Anes (Studio73) <abraham@studio73.es>
* Miguel Gandia (Studio73) <miguel@studio73.es>
* `DynApps NV <https://www.dynapps.be>`_:

  * Koen Loodts
  * Raf Ven
