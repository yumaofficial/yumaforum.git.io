* Francisco Javier Luna Vázquez <fluna@vauxoo.com>
* Tomás Álvarez <tomas@vauxoo.com>
* `Komit <https://komit-consulting.com/>`_:

  * Cuong Nguyen Mtm <cuong.nmtm@komit-consulting.com>
