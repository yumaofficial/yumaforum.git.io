Remember the tree columns' widths across sessions, and after filtering, grouping, or reordering.
