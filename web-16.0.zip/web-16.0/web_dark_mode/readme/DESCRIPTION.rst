This modules offers the dark mode for Odoo CE. The dark mode can be activated by
every user in the user menu in the top right.
