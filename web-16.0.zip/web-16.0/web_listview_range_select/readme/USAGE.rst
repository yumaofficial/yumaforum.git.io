To use this module, you need to:

#. Go to some list view.
#. Click a record.
#. Hold shift and click another record.
#. You can repeat this operation as many times as you want.
