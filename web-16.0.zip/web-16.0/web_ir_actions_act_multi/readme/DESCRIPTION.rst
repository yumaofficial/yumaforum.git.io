This module provides a way to trigger more than one action on ActionManager
