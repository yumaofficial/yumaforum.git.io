This modules modifies "many2one" and "many2manytags" form widgets so as to add some new display
control options.

Options provided includes possibility to remove "Create..." and/or "Create and
Edit..." entries from many2one drop down. You can also change default number of
proposition appearing in the drop-down. Or prevent the dialog box poping in
case of validation error.

If not specified, the module will avoid proposing any of the create options
if the current user has no permission rights to create the related object.
