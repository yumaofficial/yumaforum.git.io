* Samuel Fringeli
* `Tecnativa <https://www.tecnativa.com>`__:

  * João Marques
  * Alexandre D. Díaz
  * Carlos Roca

* Thanakrit Pintana
* `Factorlibre <https://www.factorlibre.com>`__:

  * Hugo Santos
