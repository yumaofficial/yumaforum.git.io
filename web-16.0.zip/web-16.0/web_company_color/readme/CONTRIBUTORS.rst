* Jordi Ballester Alomar <jordi.ballester@forgeflow.com> (ForgeFlow)
* Lois Rilo <lois.rilo@forgeflow.com> (ForgeFlow)
* Simone Orsi <simone.orsi@camptocamp.com>
* Iván Antón <ozono@ozonomultimedia.com>
* Bernat Puig <bernat.puig@forgeflow.com> (ForgeFlow)
* Dhara Solanki <dhara.solanki@initos.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Jairo Llopis
  * Alexandre Díaz
  * Carlos Roca
