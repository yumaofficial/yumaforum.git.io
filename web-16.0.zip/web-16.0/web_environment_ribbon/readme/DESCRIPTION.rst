Mark a Test Environment with a red ribbon on the top left corner in every page
