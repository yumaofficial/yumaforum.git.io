* Go to "Dashboard > Overview" and select a category

* The tile configured is displayed with the up to date count and average values of the selected domain.

.. image:: ../static/description/tile_tile_kanban.png

* By clicking on the item, you'll navigate to the tree view of the according model.

.. image:: ../static/description/tile_tile_2_tree_view.png
