Let reload the data in a view, while closing a wizard, without reloading the page.
