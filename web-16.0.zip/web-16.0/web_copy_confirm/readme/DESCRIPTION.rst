This module will show a confirmation dialog when the user selects the
`Duplicate` option from the `Action` dropdown in the standard form view.
